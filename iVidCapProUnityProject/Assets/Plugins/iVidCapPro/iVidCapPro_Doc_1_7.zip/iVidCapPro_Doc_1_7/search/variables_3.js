var searchData=
[
  ['saveaudio',['saveAudio',['../classi_vid_cap_pro.html#a8ae11e3d94743eae075d7dbfb16775a0',1,'iVidCapPro']]],
  ['syncwaittime',['syncWaitTime',['../classi_vid_cap_pro.html#a5e566b947f433dbd3ab9fc09a3c3e553',1,'iVidCapPro']]]
];
