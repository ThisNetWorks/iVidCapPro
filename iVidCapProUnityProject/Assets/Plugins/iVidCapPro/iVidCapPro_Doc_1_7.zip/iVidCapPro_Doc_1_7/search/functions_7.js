var searchData=
[
  ['sessioncompletedelegate',['SessionCompleteDelegate',['../classi_vid_cap_pro.html#a174d7135ffe2fcfc1090fcff4c4de4ec',1,'iVidCapPro']]],
  ['sessionerrordelegate',['SessionErrorDelegate',['../classi_vid_cap_pro.html#a43571a3f899e307407e6f56327b51b8e',1,'iVidCapPro']]],
  ['setcaptureviewport',['SetCaptureViewport',['../classi_vid_cap_pro_video.html#a370daebb4be93fd8dfe4240cacf7c56f',1,'iVidCapProVideo']]],
  ['setcustomrendertexture',['SetCustomRenderTexture',['../classi_vid_cap_pro.html#a3f5ec5965a969867a4e775a2764a91c8',1,'iVidCapPro']]],
  ['setdebug',['SetDebug',['../classi_vid_cap_pro.html#a16a23e121921ae9acb5b5a91ef9199df',1,'iVidCapPro.SetDebug()'],['../classi_vid_cap_pro_edit.html#a32482785e592c6f2c3c8067eb2118baa',1,'iVidCapProEdit.SetDebug()']]]
];
