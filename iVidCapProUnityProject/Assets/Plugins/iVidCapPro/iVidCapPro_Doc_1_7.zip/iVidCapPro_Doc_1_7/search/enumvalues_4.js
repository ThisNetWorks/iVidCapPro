var searchData=
[
  ['locked',['Locked',['../classi_vid_cap_pro.html#a1652a6c7e6f406f22fab8e45910cc2bcad0f2e5376298c880665077b565ffd7dd',1,'iVidCapPro']]]
];
