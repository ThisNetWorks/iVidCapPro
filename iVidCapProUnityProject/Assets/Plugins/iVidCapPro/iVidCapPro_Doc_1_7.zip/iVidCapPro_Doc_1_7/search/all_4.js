var searchData=
[
  ['endrecordingsession',['EndRecordingSession',['../classi_vid_cap_pro.html#abaf2d2a9c22c89fe9ac05717d5580aa9',1,'iVidCapPro']]],
  ['endrecordingsessionwithaudiofiles',['EndRecordingSessionWithAudioFiles',['../classi_vid_cap_pro.html#acef78a9564e3d79d0b164ab90c07dd26',1,'iVidCapPro']]]
];
