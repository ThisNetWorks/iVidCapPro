var searchData=
[
  ['ok',['OK',['../classi_vid_cap_pro.html#a226650d02b62092e3e57efe467f790f1ae0aa021e21dddbd6d8cecec71e9cf564',1,'iVidCapPro.OK()'],['../classi_vid_cap_pro_edit.html#a3a090f984264fa7559eb18e9cc0561e4ae0aa021e21dddbd6d8cecec71e9cf564',1,'iVidCapProEdit.OK()']]]
];
