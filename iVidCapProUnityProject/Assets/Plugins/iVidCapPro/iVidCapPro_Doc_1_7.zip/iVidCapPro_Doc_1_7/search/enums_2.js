var searchData=
[
  ['sessionstatuscode',['SessionStatusCode',['../classi_vid_cap_pro.html#a226650d02b62092e3e57efe467f790f1',1,'iVidCapPro']]],
  ['statuscode',['StatusCode',['../classi_vid_cap_pro_edit.html#a3a090f984264fa7559eb18e9cc0561e4',1,'iVidCapProEdit']]]
];
