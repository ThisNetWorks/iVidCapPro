var searchData=
[
  ['log',['Log',['../classi_vid_cap_pro.html#a0fed135bafcb484d15e50ab0dfec5c89',1,'iVidCapPro.Log()'],['../classi_vid_cap_pro_edit.html#a19f7699c8950586981e7e065cf6f04ee',1,'iVidCapProEdit.Log()']]]
];
