var searchData=
[
  ['save_5fvideo_5fto_5falbum',['Save_Video_To_Album',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172ca6e7d7aa6b8b897f37606fc71c4de1e6c',1,'iVidCapPro']]],
  ['save_5fvideo_5fto_5fdocuments',['Save_Video_To_Documents',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172ca6a874225aec038c6af741eb42009fd6a',1,'iVidCapPro']]],
  ['saveaudio',['saveAudio',['../classi_vid_cap_pro.html#a8ae11e3d94743eae075d7dbfb16775a0',1,'iVidCapPro']]],
  ['sessioncompletedelegate',['SessionCompleteDelegate',['../classi_vid_cap_pro.html#a174d7135ffe2fcfc1090fcff4c4de4ec',1,'iVidCapPro']]],
  ['sessionerrordelegate',['SessionErrorDelegate',['../classi_vid_cap_pro.html#a43571a3f899e307407e6f56327b51b8e',1,'iVidCapPro']]],
  ['sessionstatuscode',['SessionStatusCode',['../classi_vid_cap_pro.html#a226650d02b62092e3e57efe467f790f1',1,'iVidCapPro']]],
  ['setcaptureviewport',['SetCaptureViewport',['../classi_vid_cap_pro_video.html#a370daebb4be93fd8dfe4240cacf7c56f',1,'iVidCapProVideo']]],
  ['setcustomrendertexture',['SetCustomRenderTexture',['../classi_vid_cap_pro.html#a3f5ec5965a969867a4e775a2764a91c8',1,'iVidCapPro']]],
  ['setdebug',['SetDebug',['../classi_vid_cap_pro.html#a16a23e121921ae9acb5b5a91ef9199df',1,'iVidCapPro.SetDebug()'],['../classi_vid_cap_pro_edit.html#a32482785e592c6f2c3c8067eb2118baa',1,'iVidCapProEdit.SetDebug()']]],
  ['statuscode',['StatusCode',['../classi_vid_cap_pro_edit.html#a3a090f984264fa7559eb18e9cc0561e4',1,'iVidCapProEdit']]],
  ['syncwaittime',['syncWaitTime',['../classi_vid_cap_pro.html#a5e566b947f433dbd3ab9fc09a3c3e553',1,'iVidCapPro']]]
];
