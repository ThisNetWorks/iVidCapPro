var searchData=
[
  ['beginrecordingsession',['BeginRecordingSession',['../classi_vid_cap_pro.html#a80c0561bd6445b31980b7ed750d865cf',1,'iVidCapPro']]]
];
