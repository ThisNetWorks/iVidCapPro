var searchData=
[
  ['notificationdelegate',['NotificationDelegate',['../classi_vid_cap_pro_edit.html#a13e2bc2bb598cf0589ca6acc3fad0d71',1,'iVidCapProEdit']]]
];
