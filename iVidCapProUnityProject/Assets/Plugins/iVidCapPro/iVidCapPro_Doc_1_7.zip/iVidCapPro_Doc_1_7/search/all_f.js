var searchData=
[
  ['throttled',['Throttled',['../classi_vid_cap_pro.html#a1652a6c7e6f406f22fab8e45910cc2bcaca7bd438b66e51a7c4a108f471b9f18f',1,'iVidCapPro']]]
];
