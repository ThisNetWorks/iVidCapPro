var searchData=
[
  ['captureaudio',['CaptureAudio',['../classi_vid_cap_pro.html#a8a1282f1fdb6ced6c3ea9b447a9e4a58',1,'iVidCapPro']]],
  ['captureframeratelock',['CaptureFramerateLock',['../classi_vid_cap_pro.html#a1652a6c7e6f406f22fab8e45910cc2bc',1,'iVidCapPro']]],
  ['configuregammasetting',['ConfigureGammaSetting',['../classi_vid_cap_pro.html#a41b4f802b8ced7123b753009ea63a6fc',1,'iVidCapPro']]],
  ['configurevideosettings',['ConfigureVideoSettings',['../classi_vid_cap_pro.html#a793732730916c2043a8af803410a0058',1,'iVidCapPro']]],
  ['copy_5fvideo_5fto_5fphoto_5falbum',['Copy_Video_To_Photo_Album',['../classi_vid_cap_pro_edit.html#a514a98b4c83443d8eebaaae6e272b8a9a3909d05e85b260b70b801b3c37829496',1,'iVidCapProEdit']]],
  ['copyvideofiletophotoalbum',['CopyVideoFileToPhotoAlbum',['../classi_vid_cap_pro_edit.html#a22664189aa546a32cb9a590bed115bd4',1,'iVidCapProEdit']]]
];
