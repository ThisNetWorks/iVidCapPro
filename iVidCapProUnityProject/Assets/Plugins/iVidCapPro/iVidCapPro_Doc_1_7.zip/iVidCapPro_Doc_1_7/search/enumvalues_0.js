var searchData=
[
  ['audio',['Audio',['../classi_vid_cap_pro.html#a8a1282f1fdb6ced6c3ea9b447a9e4a58ab22f0418e8ac915eb66f829d262d14a2',1,'iVidCapPro']]],
  ['audio_5fplus_5fmic',['Audio_Plus_Mic',['../classi_vid_cap_pro.html#a8a1282f1fdb6ced6c3ea9b447a9e4a58a6b3a792e7fe26dacb65a14b832c7ee4f',1,'iVidCapPro']]]
];
