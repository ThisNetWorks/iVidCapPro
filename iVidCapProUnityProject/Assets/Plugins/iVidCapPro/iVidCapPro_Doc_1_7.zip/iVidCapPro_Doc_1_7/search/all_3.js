var searchData=
[
  ['discard_5fvideo',['Discard_Video',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172ca1ef8895e68b56e95eb8b711f5c3f57c5',1,'iVidCapPro']]]
];
