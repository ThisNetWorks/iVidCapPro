var searchData=
[
  ['registernotificationdelegate',['RegisterNotificationDelegate',['../classi_vid_cap_pro_edit.html#a2f057d49db9f23fb3062c345541ca534',1,'iVidCapProEdit']]],
  ['registersessioncompletedelegate',['RegisterSessionCompleteDelegate',['../classi_vid_cap_pro.html#a6c11d6cc416e6f1017b49fa1b33d8b1b',1,'iVidCapPro']]],
  ['registersessionerrordelegate',['RegisterSessionErrorDelegate',['../classi_vid_cap_pro.html#a464de3bd847b16c3885e988417dbe6e5',1,'iVidCapPro']]]
];
