var searchData=
[
  ['videocameras',['videoCameras',['../classi_vid_cap_pro.html#a1c4d8e7884aa393b1ffe92341c632659',1,'iVidCapPro']]],
  ['videodisposition',['VideoDisposition',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172c',1,'iVidCapPro']]]
];
