var searchData=
[
  ['copy_5fvideo_5fto_5fphoto_5falbum',['Copy_Video_To_Photo_Album',['../classi_vid_cap_pro_edit.html#a514a98b4c83443d8eebaaae6e272b8a9a3909d05e85b260b70b801b3c37829496',1,'iVidCapProEdit']]]
];
