var searchData=
[
  ['save_5fvideo_5fto_5falbum',['Save_Video_To_Album',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172ca6e7d7aa6b8b897f37606fc71c4de1e6c',1,'iVidCapPro']]],
  ['save_5fvideo_5fto_5fdocuments',['Save_Video_To_Documents',['../classi_vid_cap_pro.html#a1a34e69d64f2a271fba8a17d0406172ca6a874225aec038c6af741eb42009fd6a',1,'iVidCapPro']]]
];
