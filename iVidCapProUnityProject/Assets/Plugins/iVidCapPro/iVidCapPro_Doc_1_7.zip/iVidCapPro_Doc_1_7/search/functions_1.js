var searchData=
[
  ['configuregammasetting',['ConfigureGammaSetting',['../classi_vid_cap_pro.html#a41b4f802b8ced7123b753009ea63a6fc',1,'iVidCapPro']]],
  ['configurevideosettings',['ConfigureVideoSettings',['../classi_vid_cap_pro.html#a793732730916c2043a8af803410a0058',1,'iVidCapPro']]],
  ['copyvideofiletophotoalbum',['CopyVideoFileToPhotoAlbum',['../classi_vid_cap_pro_edit.html#a22664189aa546a32cb9a590bed115bd4',1,'iVidCapProEdit']]]
];
