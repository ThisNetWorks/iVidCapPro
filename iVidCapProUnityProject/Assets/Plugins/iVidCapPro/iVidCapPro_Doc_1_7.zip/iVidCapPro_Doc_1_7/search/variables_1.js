var searchData=
[
  ['isdedicated',['isDedicated',['../classi_vid_cap_pro_video.html#aba726c90a1684029c0259b9114041998',1,'iVidCapProVideo']]]
];
