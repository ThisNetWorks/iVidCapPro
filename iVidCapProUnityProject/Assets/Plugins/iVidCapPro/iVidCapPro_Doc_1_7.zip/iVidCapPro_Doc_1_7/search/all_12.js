var searchData=
[
  ['write_5fvideo',['Write_Video',['../classi_vid_cap_pro_edit.html#a514a98b4c83443d8eebaaae6e272b8a9afa863bd6e45bf02b1525c372087f6777',1,'iVidCapProEdit']]]
];
