var searchData=
[
  ['no_5faudio',['No_Audio',['../classi_vid_cap_pro.html#a8a1282f1fdb6ced6c3ea9b447a9e4a58aa248212b4fbec3ddfce5141b5576d43a',1,'iVidCapPro']]]
];
